This directory contains Excel Spreadsheets that have been created by pasting the "copied to clipboard" results of example spreadsheet loads
