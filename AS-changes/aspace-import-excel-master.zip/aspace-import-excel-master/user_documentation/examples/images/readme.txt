This files contains images that are used in the /user_documentation/examples/readme.md
